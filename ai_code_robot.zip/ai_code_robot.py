
import os
import ast
from pathlib import Path
from github import Github  # pip install PyGithub
from openai import OpenAI  # pip install openai

# ----------------- 配置 -----------------
CODEBASE_PATH = "./sample_project"
GITHUB_REPO = "username/repo_name"  # 仓库全名
GITHUB_TOKEN = "YOUR_GITHUB_TOKEN"
OPENAI_API_KEY = "YOUR_OPENAI_API_KEY"
BRANCH_PREFIX = "ai-refactor/"

client = OpenAI(api_key=OPENAI_API_KEY)
gh = Github(GITHUB_TOKEN)
repo = gh.get_repo(GITHUB_REPO)

# ----------------- Agent 1: 扫描代码库 -----------------
def scan_code(base_path):
    py_files = []
    for root, dirs, files in os.walk(base_path):
        for file in files:
            if file.endswith(".py"):
                py_files.append(os.path.join(root, file))
    return py_files

# ----------------- Agent 2: AI 代码重构 -----------------
def ai_refactor_code(code, file_name):
    prompt = f"""你是一个 AI 代码优化助手，请重构以下 Python 代码，保持功能不变但提高可读性、性能和规范性。
文件: {file_name}
代码:
{code}
请只返回重构后的完整代码。
"""
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
        temperature=0
    )
    return response.choices[0].message.content.strip()

# ----------------- Agent 3: 自动生成单元测试 -----------------
def ai_generate_test(code, file_name):
    prompt = f"""请根据以下 Python 代码生成可运行的 unittest 测试模板，每个函数至少有一个简单测试。
文件: {file_name}
代码:
{code}
"""
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
        temperature=0
    )
    return response.choices[0].message.content.strip()

# ----------------- Agent 4: 自动提交 PR -----------------
def create_pull_request(branch_name, files):
    source = repo.get_branch("main")
    repo.create_git_ref(ref=f"refs/heads/{branch_name}", sha=source.commit.sha)
    for file_path, content in files.items():
        rel_path = os.path.relpath(file_path, CODEBASE_PATH)
        try:
            repo.update_file(
                path=rel_path,
                message=f"[AI] 自动重构 {rel_path}",
                content=content,
                sha=repo.get_contents(rel_path, ref="main").sha,
                branch=branch_name
            )
        except Exception as e:
            print(f"提交 {rel_path} 失败: {e}")
    pr = repo.create_pull(
        title="[AI] 自动重构代码",
        body="此 PR 由 AI 代码优化机器人自动生成，包含重构和测试模板。",
        head=branch_name,
        base="main"
    )
    print(f"PR 已创建: {pr.html_url}")

# ----------------- 主流程 -----------------
def main():
    py_files = scan_code(CODEBASE_PATH)
    print(f"扫描到 {len(py_files)} 个 Python 文件")
    branch_name = BRANCH_PREFIX + "auto-refactor"
    updated_files = {}
    for file_path in py_files:
        with open(file_path, "r", encoding="utf-8") as f:
            code = f.read()
        print(f"处理文件: {file_path}")
        refactored_code = ai_refactor_code(code, file_path)
        test_code = ai_generate_test(refactored_code, file_path)
        full_content = refactored_code + "\n\n# 自动生成测试\n" + test_code
        updated_files[file_path] = full_content
    create_pull_request(branch_name, updated_files)

if __name__ == "__main__":
    main()
